import { GameState } from '@/src/System/AI/In-Game/Logic/GameLogic';

/**
 * West Grand Arcade North Rendering
 */
export const drawWestGrandArcadeNorth = (ctx: CanvasRenderingContext2D, width: number, height: number, state: GameState, horizon: number) => {
  ctx.fillStyle = "#2E8B57";
  ctx.fillRect(0, 0, width, horizon);
};
