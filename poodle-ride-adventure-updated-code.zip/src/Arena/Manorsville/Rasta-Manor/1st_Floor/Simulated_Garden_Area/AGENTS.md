# Local Directory Protection Notice: src/Arena/Manorsville/Rasta-Manor/1st_Floor/Simulated_Garden_Area

## 20000% Ultra-Broad Craftsmanship & Invariant Protections
- This directory and all enclosed modules are protected under **20000% Ultra-Broad Protections**.
- **Zero-Stubbing & Zero-Pruning**: Automated simplifications, deletions, mock fallbacks, and modifications are strictly forbidden.
- **Zero-Fallback Policy**: Explicit branching and non-default logic must be preserved for all characters and subsystems.
- Refer to root /AGENTS.md and /PROTECTIONS_NOTICES.md for full systemic invariants.
